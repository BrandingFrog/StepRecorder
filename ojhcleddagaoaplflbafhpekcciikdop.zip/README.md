# ChromeStepRecorder
 Record manual steps into text, identifiers and screesnhots

# Key Features:
 - Automatically record detailed user actions and screenshots from manual interaction with web pages.
 - Captures events, object identifiers, URLs, titles and screenshots
 - Once ready, view the detailed results, press ctrl+s and create a single, detailed flat file of test evidence of every action undertaken in the browser.

# Why?
As a tester, I'm forever capturing test evidence for steps that are undertaken. This is especially tricky when doing exploratory testing and trying to recreate any issues.
This extension is the solution to creating highly detailed test evidence files with no effort.

Do your test, save the results web page and upload it to whichever management tool is used.


# Use cases:
 - Manual test execution evidence capture
 - Exploratory test tracking
 - SME/Business process/data capture - they do it, you can harvest their knowledge
 - Story-booking the execution of automation (have the extension turned on while automation runs)
 - Encourage non-testers to capture the best level of detail possible


# Instructions:
1. Install the extension
2. Click the extension and open the popup  (strongly recommend pinning the extension!)
3. Click the slider to turn on recording - the icon adds a red dot.
4. Create a new tab and do your test actions!
5. At any point, open the extension and press "Peek Steps" to see a subset of has been recorded.
6. For any checkpoints, open the popup and press "Capture Current State" to snap a pic of the application. This is especially useful for the final state of the appplication. 
7. When complete, click the slider to stop recording  (you can turn it on and off as many time as required) and click "Open Detailed Results Tab".
8. Review the steps, press ctrl+s and save the detailed results web page.
9. Ready for the next test?  - Open the popup and press Clear Steps

*The extension should not record password entries by filtering element 'type=password'  - but please validate result files before saving.
